#include "partida.h"


int main(void)
{

    PAR_RealizaJogo();

return 0;
}